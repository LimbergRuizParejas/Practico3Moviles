package com.example.minematch

import android.annotation.SuppressLint
import android.os.Bundle
import androidx.activity.enableEdgeToEdge
import androidx.appcompat.app.AppCompatActivity
import androidx.core.view.ViewCompat
import androidx.core.view.WindowInsetsCompat
import com.example.minematch.R.id.main

class MainActivity : AppCompatActivity() {
    private lateinit var vistaJuego: VistaJuego

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContentView(R.layout.activity_main)

        vistaJuego = findViewById(R.id.vistajuego)

     
        ViewCompat.setOnApplyWindowInsetsListener(findViewById(main)) { v, insets ->
            val barrasDelSistema = insets.getInsets(WindowInsetsCompat.Type.systemBars())
            v.setPadding(barrasDelSistema.left, barrasDelSistema.top, barrasDelSistema.right, barrasDelSistema.bottom)
            insets
        }
    }
}
