package com.example.minematch

import android.content.Context
import android.graphics.Canvas
import android.graphics.Color
import android.graphics.Paint
import android.graphics.drawable.Drawable
import android.util.AttributeSet
import android.view.MotionEvent
import android.view.View
import androidx.core.content.ContextCompat

class VistaJuego : View {

    private val numFilas = 8
    private val numColumnas = 8
    private val tamanoCelda = 100
    private val tablero: Array<IntArray> = Array(numFilas) { IntArray(numColumnas) }
    private var filaSeleccionada = -1
    private var columnaSeleccionada = -1
    private val pincel: Paint = Paint().apply {
        color = Color.BLACK
        style = Paint.Style.STROKE
        strokeWidth = 2f
    }
    private val pincelGema: Paint = Paint()
    private val pincelPoder: Paint = Paint().apply {
        style = Paint.Style.FILL
        strokeWidth = 5f
    }
    private var poderActivado = false
    private var listaPoderes: ArrayList<Poder> = ArrayList()
    private var tipoGemaPoder = -1 // Tipo de gema asociado al poder especial
    private var dibujoPoder: Drawable? = null // Drawable para representar el poder

    enum class Poder {
        Rayo,
        Fuego,
        Cubo
    }

    constructor(contexto: Context) : super(contexto) {
        inicializar()
    }

    constructor(contexto: Context, attrs: AttributeSet?) : super(contexto, attrs) {
        inicializar()
    }

    private fun inicializar() {
        // Inicializar el tablero con valores aleatorios
        for (i in 0 until numFilas) {
            for (j in 0 until numColumnas) {
                tablero[i][j] = (1..6).random() // Números aleatorios del 1 al 6
            }
        }
    }

    override fun onDraw(canvas: Canvas) {
        super.onDraw(canvas)

        // Dibujar el fondo del tablero
        canvas.drawColor(Color.TRANSPARENT)

        // Dibujar las celdas del tablero
        for (i in 0 until numFilas) {
            for (j in 0 until numColumnas) {
                val izquierda = j * tamanoCelda.toFloat()
                val arriba = i * tamanoCelda.toFloat()
                val derecha = izquierda + tamanoCelda
                val abajo = arriba + tamanoCelda
                canvas.drawRect(izquierda, arriba, derecha, abajo, pincel)

                // Dibuja los poderes si están activados y la posición coincide con la posición de la gema con poder especial
                if (poderActivado && i == filaSeleccionada && j == columnaSeleccionada) {
                    dibujarPoder(canvas, i, j)
                } else {
                    dibujarGema(canvas, i, j, tablero[i][j])
                }
            }
        }
    }

    override fun onTouchEvent(event: MotionEvent): Boolean {
        when (event.action) {
            MotionEvent.ACTION_DOWN -> {
                val columna = (event.x / tamanoCelda).toInt()
                val fila = (event.y / tamanoCelda).toInt()

                // Verificar si la gema seleccionada tiene asociado un poder especial
                if (tablero[fila][columna] == tipoGemaPoder) {
                    filaSeleccionada = fila
                    columnaSeleccionada = columna
                    poderActivado = true
                    invalidate()
                    return true
                }

                if (!poderActivado) {
                    if (filaSeleccionada == -1 || columnaSeleccionada == -1) {
                        filaSeleccionada = fila
                        columnaSeleccionada = columna
                    } else {
                        if (esAdyacente(filaSeleccionada, columnaSeleccionada, fila, columna)) {
                            intercambiarGemas(filaSeleccionada, columnaSeleccionada, fila, columna)
                            val eliminadas = verificarYEliminarCoincidencias()
                            if (eliminadas) {
                                llenarEspaciosVacios()
                                activarPoder() // Activar el poder solo después de verificar los movimientos
                            } else {
                                intercambiarGemas(filaSeleccionada, columnaSeleccionada, fila, columna)
                            }
                        }
                        filaSeleccionada = -1
                        columnaSeleccionada = -1
                    }
                } else {
                    // Activar el poder especial
                    if (listaPoderes.isNotEmpty() && listaPoderes.last() != null) {
                        when (listaPoderes.last()) {
                            Poder.Cubo -> usarPoderCubo(fila, columna)
                            Poder.Fuego -> usarPoderFuego(fila, columna)
                            Poder.Rayo -> usarPoderRayo(fila, columna)
                        }
                        listaPoderes.removeAt(listaPoderes.lastIndex)
                        poderActivado = false
                    }
                }

                invalidate()
            }
        }
        return true
    }

    private fun esAdyacente(fila1: Int, columna1: Int, fila2: Int, columna2: Int): Boolean {
        return (fila1 == fila2 && Math.abs(columna1 - columna2) == 1) || (columna1 == columna2 && Math.abs(fila1 - fila2) == 1)
    }

    private fun intercambiarGemas(fila1: Int, columna1: Int, fila2: Int, columna2: Int) {
        val temp = tablero[fila1][columna1]
        tablero[fila1][columna1] = tablero[fila2][columna2]
        tablero[fila2][columna2] = temp
    }

    private fun verificarYEliminarCoincidencias(): Boolean {
        var eliminadas = false
        // Verificar coincidencias en filas
        for (i in 0 until numFilas) {
            for (j in 0 until numColumnas - 2) {
                if (tablero[i][j] == tablero[i][j + 1] && tablero[i][j] == tablero[i][j + 2]) {
                    tablero[i][j] = 0
                    tablero[i][j + 1] = 0
                    tablero[i][j + 2] = 0
                    eliminadas = true
                }
            }
        }
        // Verificar coincidencias en columnas
        for (j in 0 until numColumnas) {
            for (i in 0 until numFilas - 2) {
                if (tablero[i][j] == tablero[i + 1][j] && tablero[i][j] == tablero[i + 2][j]) {
                    tablero[i][j] = 0
                    tablero[i + 1][j] = 0
                    tablero[i + 2][j] = 0
                    eliminadas = true
                }
            }
        }
        return eliminadas
    }

    private fun llenarEspaciosVacios() {
        for (j in 0 until numColumnas) {
            var k = numFilas - 1
            for (i in numFilas - 1 downTo 0) {
                if (tablero[i][j] != 0) {
                    tablero[k][j] = tablero[i][j]
                    k--
                }
            }
            while (k >= 0) {
                tablero[k][j] = (1..6).random()
                k--
            }
        }
    }

    private fun dibujarGema(canvas: Canvas, fila: Int, columna: Int, tipoGema: Int) {
        val radioGema = tamanoCelda / 3f
        val centroX = columna * tamanoCelda + tamanoCelda / 2f
        val centroY = fila * tamanoCelda + tamanoCelda / 2f
        pincelGema.color = getColorGema(tipoGema)
        canvas.drawCircle(centroX, centroY, radioGema, pincelGema)
    }

    private fun dibujarPoder(canvas: Canvas, fila: Int, columna: Int) {
        if (dibujoPoder != null) {
            val centroX = columna * tamanoCelda + tamanoCelda / 2f
            val centroY = fila * tamanoCelda + tamanoCelda / 2f
            dibujoPoder?.let {
                val mitadAncho = it.intrinsicWidth / 2
                val mitadAlto = it.intrinsicHeight / 2
                val maxSize = tamanoCelda * 0.8f // Tamaño máximo de la imagen (80% del tamaño de la celda)
                val scaleFactor = if (mitadAncho > mitadAlto) {
                    maxSize / mitadAncho
                } else {
                    maxSize / mitadAlto
                }
                val nuevoAncho = (mitadAncho * scaleFactor).toInt()
                val nuevoAlto = (mitadAlto * scaleFactor).toInt()
                val izquierda = (centroX - nuevoAncho / 2).toInt()
                val arriba = (centroY - nuevoAlto / 2).toInt()
                val derecha = (centroX + nuevoAncho / 2).toInt()
                val abajo = (centroY + nuevoAlto / 2).toInt()
                it.setBounds(izquierda, arriba, derecha, abajo)
                it.draw(canvas)
            }
        }
    }

    private fun activarPoder() {
        val poderAleatorio = when ((1..3).random()) {
            1 -> Poder.Rayo
            2 -> Poder.Fuego
            else -> Poder.Cubo
        }
        listaPoderes.add(poderAleatorio)
        poderActivado = true
        dibujoPoder = getDibujoPoder(poderAleatorio)
        // Asignar el tipo de gema asociado al poder
        tipoGemaPoder = if (poderAleatorio == Poder.Cubo) tablero[filaSeleccionada][columnaSeleccionada] else -1

    }

    private fun usarPoderRayo(fila: Int, columna: Int) {
        // Eliminar toda la fila
        for (i in 0 until numFilas) {
            tablero[i][columna] = 0
        }

        // Eliminar toda la columna
        for (j in 0 until numColumnas) {
            tablero[fila][j] = 0
        }

        // Mover gemas hacia abajo para llenar los espacios vacíos
        for (j in 0 until numColumnas) {
            var k = numFilas - 1
            for (i in numFilas - 1 downTo 0) {
                if (tablero[i][j] != 0) {
                    tablero[k][j] = tablero[i][j]
                    if (k != i) {
                        tablero[i][j] = 0
                    }
                    k--
                }
            }
            while (k >= 0) {
                tablero[k][j] = 0
                k--
            }
        }
    }

    private fun usarPoderFuego(fila: Int, columna: Int) {
        // Eliminar todos las gemas adyacentes (horizontalmente y verticalmente)
        for (i in (fila - 1)..(fila + 1)) {
            for (j in (columna - 1)..(columna + 1)) {
                if (i in 0 until numFilas && j in 0 until numColumnas) {
                    tablero[i][j] = 0
                }
            }
        }

        // Mover gemas hacia abajo para llenar los espacios vacíos
        for (j in 0 until numColumnas) {
            var k = numFilas - 1
            for (i in numFilas - 1 downTo 0) {
                if (tablero[i][j] != 0) {
                    tablero[k][j] = tablero[i][j]
                    if (k != i) {
                        tablero[i][j] = 0
                    }
                    k--
                }
            }
            while (k >= 0) {
                tablero[k][j] = 0
                k--
            }
        }
    }

    private fun usarPoderCubo(fila: Int, columna: Int) {
        val tipoGemaObjetivo = tablero[fila][columna]
        for (i in 0 until numFilas) {
            for (j in 0 until numColumnas) {
                if (tablero[i][j] == tipoGemaObjetivo) {
                    tablero[i][j] = 0
                }
            }
        }
        for (j in 0 until numColumnas) {
            var k = numFilas - 1
            for (i in numFilas - 1 downTo 0) {
                if (tablero[i][j] != 0) {
                    tablero[k][j] = tablero[i][j]
                    if (k != i) {
                        tablero[i][j] = 0
                    }
                    k--
                }
            }
            while (k >= 0) {
                tablero[k][j] = 0
                k--
            }
        }
    }

    private fun getColorGema(tipoGema: Int): Int {
        return when (tipoGema) {
            1 -> Color.RED
            2 -> Color.GREEN
            3 -> Color.BLUE
            4 -> Color.YELLOW
            5 -> Color.CYAN
            else -> Color.WHITE
        }
    }

    private fun getDibujoPoder(poder: Poder): Drawable? {
        return when (poder) {
            Poder.Cubo -> ContextCompat.getDrawable(context, R.drawable.cubo)
            Poder.Fuego -> ContextCompat.getDrawable(context, R.drawable.fuego)
            Poder.Rayo -> ContextCompat.getDrawable(context, R.drawable.rayo)
        }
    }
}
